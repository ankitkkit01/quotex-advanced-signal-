# Main bot code will be here
